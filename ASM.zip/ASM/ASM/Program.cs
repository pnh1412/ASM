﻿using System;
using ASM.Manager;
using ASM.Model;
namespace ASM {
    class Program {
        static void Main(string[] args) {
            run();
        }
        static int menu() {
            Console.WriteLine("-----Menu------");
            Console.WriteLine("1. List of Class");
            Console.WriteLine("2. Management Class");
            Console.WriteLine("3. Add Class");
            Console.WriteLine("4. Management Industry");
            Console.WriteLine("5. Management School Year");
            Console.WriteLine("6. Exit");
            Console.WriteLine("Please choose from 1-6");
            int i = CheckError.CheckChoose(Console.ReadLine());
            return i;
        }
        static void run() {
            ManagerIndustry.readFile();
            ManagerSchoolYear.readFile();
            ManagerClass.readFile();
            ManagerStudent.readFile();
            int check;
            do {
                check = menu();
                switch (check) {
                    case 1:
                        ManagerClass.display();
                        break;
                    case 2:
                        Console.Write("Input ID Class: ");
                        string IDClass = Console.ReadLine();
                        Class lop = ManagerClass.CheckClass(IDClass);
                        int menuClass;
                        if (lop != null) {
                            do {
                                menuClass = ManagerClass.Menu();
                                switch (menuClass) {
                                    case 1:
                                        ManagerStudent.display(lop);
                                        break;
                                    case 2:
                                        ManagerStudent.addStudent(lop.IOC1);
                                        break;
                                    case 3:
                                        ManagerStudent.DeleteStudent(lop);
                                        break;
                                    case 4:
                                        break;
                                    default:
                                        Console.WriteLine("Just only 1-4");
                                        break;
                                }
                            }while (menuClass != 4);
                        }
                        else {
                            Console.WriteLine("Didnt found class"); 
                        }
                        break;
                     case 3:
                        if (ManagerSchoolYear.listschoolyear.Count == 0)
                        {
                            Console.WriteLine("Please add more School Year before add class");
                        }
                        else if (ManagerIndustry.listindustry.Count == 0)
                        {
                            Console.WriteLine("Please add more Industry before add class");
                        }
                        else {
                            ManagerClass.AddClass();
                        }
                        break;
                      case 4:
                        int menuIndustry;
                        do {
                            menuIndustry = ManagerIndustry.Menu();
                            switch (menuIndustry) {
                                case 1:
                                    ManagerIndustry.display();
                                    break;
                                case 2:
                                    Console.WriteLine("Add ID Industry: ");
                                    string IDIndustry = Console.ReadLine();
                                    Industry k = ManagerIndustry.CheckIndustry(IDIndustry);
                                    ManagerIndustry.displayclass(k);
                                    break;
                                case 3:
                                    ManagerIndustry.add();
                                    break;
                                case 4:
                                    break;
                                default:
                                    Console.WriteLine("Only from 1-4");
                                    break;
                            }
                        }while(menuIndustry != 4);
                        break;
                    case 5:
                        int menuSchoolYear;
                        do
                        {
                            menuSchoolYear= ManagerSchoolYear.Menu();
                            switch (menuSchoolYear)
                            {
                                case 1:
                                    ManagerSchoolYear.display();
                                    break;
                                case 2:
                                    Console.WriteLine("Add ID School Year: ");
                                    string IDSY = Console.ReadLine();
                                    SchoolYear s = ManagerSchoolYear.CheckSchoolYear(IDSY);
                                    ManagerSchoolYear.displayclass(s);
                                    break;
                                case 3:
                                    ManagerIndustry.add();
                                    break;
                                case 4:
                                    break;
                                default:
                                    Console.WriteLine("Only from 1-4");
                                    break;
                            }
                        } while (menuSchoolYear != 4);
                        break;
                     case 6:
                        break;
                    default:
                        Console.WriteLine("Only from 1-6");
                        break;
                }
            } while (check != 6);
        }
    }
}