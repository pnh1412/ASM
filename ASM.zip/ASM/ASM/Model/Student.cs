﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASM.Model
{
    class Student
    {
        string ID;
        string IOC; // id of class
        string IDIndustry;
        string Name;
        string DOF;
        string Gender;
        string Address;
        string PhoneNumber;

        public string ID1 { get => ID; set => ID = value; }
        public string IOC1 { get => IOC; set => IOC = value; }
        public string IDIndustry1 { get => IDIndustry; set => IDIndustry = value; }
        public string Name1 { get => Name; set => Name = value; }
        public string DOF1 { get => DOF; set => DOF = value; }
        public string Gender1 { get => Gender; set => Gender = value; }
        public string Address1 { get => Address; set => Address = value; }
        public string PhoneNumber1 { get => PhoneNumber; set => PhoneNumber = value; }

        public Student(string iD, string iOC, string iDIndustry, string name, string dOF, string gender, string address, string phoneNumber)
        {
            ID = iD;
            IOC = iOC;
            IDIndustry = iDIndustry;
            Name = name;
            DOF = dOF;
            Gender = gender;
            Address = address;
            PhoneNumber = phoneNumber;
        }

        public Student()
        {
        }
    }
}
