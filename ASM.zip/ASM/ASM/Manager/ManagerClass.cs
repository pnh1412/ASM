﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ASM.Model;
namespace ASM.Manager
{
    class ManagerClass
    {
        public static List<Class> listclass = new List<Class>();
        public static void display() {
            int check = 0;
            Console.WriteLine("ID of class\t|\tClass\t|\tSchool Year\t|\t");
            foreach (Class lop in listclass) {
                check++;
                Console.WriteLine("(0)\t|\t(1)\t|\t(2)\t|\t(3)", lop.IOC1,lop.NameClass1, ManagerSchoolYear.CheckSchoolYear(lop.IDSY1).Ex1,ManagerIndustry.CheckIndustry(lop.IDIndustry1).NameIndustry1);
            }
            if (check == 0) {
                Console.WriteLine("No class to display");
            }
        }
        public static Class CheckClass(string IOC) {
            foreach (Class lop in listclass) {
                if (lop.IOC1.Equals(IOC)) {
                    return lop;
                }
            }
            return null;
        }
        public static int Menu() {
            int j;
            Console.WriteLine("------Management Class-------");
            Console.WriteLine("1. List of Student");
            Console.WriteLine("2. Add Student");
            Console.WriteLine("3. Delete Student");
            Console.WriteLine("4. Exit");
            Console.WriteLine("Please choose from 1-4: ");
            j = CheckError.CheckChoose(Console.ReadLine());
            return j;
        }
        public static void AddClass() {
            string IOC;
            string IDIndustry;
            string IDSY; // id of school year
            string NameClass;
            Industry k;
            SchoolYear s;
            Class lop;
            do
            {
                Console.WriteLine("Put ID Class: ");
                IOC = Console.ReadLine();
                lop = ManagerClass.CheckClass(IOC);
                if (lop != null)
                {
                    Console.WriteLine("ID class exist");
                    Console.WriteLine("Please put the ID class again");
                }
            } while (lop != null);
            do
            {
                Console.WriteLine("Put ID Industry: ");
                IDIndustry = Console.ReadLine();
                k = ManagerIndustry.CheckIndustry(IDIndustry);
                if (k != null)
                {
                    Console.WriteLine("ID Industry exist");
                    Console.WriteLine("Please put the ID Industry again");
                }
            } while (k != null);
            do
            {
                Console.WriteLine("Put ID School Year: ");
                IDSY = Console.ReadLine();
                s = ManagerSchoolYear.CheckSchoolYear(IDSY);
                if (s != null)
                {
                    Console.WriteLine("ID School Year exist");
                    Console.WriteLine("Please put the ID School Year again");
                }
            } while (s != null);
            Console.Write("Put Name Class: ");
            NameClass = Console.ReadLine();
            lop = new Class(IOC,IDIndustry,IDSY,NameClass, new List<Student>());
            listclass.Add(lop);
            k.Listclass.Add(lop);
            s.Listclass.Add(lop);
            WriteFile();
            Console.WriteLine("Add class succes!");
        }
        public static void WriteFile()
        {
            string fileName = "../../../Class.txt";
            using (BinaryWriter writter = new BinaryWriter(File.Open(fileName, FileMode.Create)))
            {
                foreach (Class lop in listclass)
                {
                    writter.Write(lop.IDIndustry1);
                    writter.Write(lop.IOC1);
                    writter.Write(lop.IDSY1);
                    writter.Write(lop.NameClass1);                   
                }
            }
        }
        public static void readFile()
        {
            try
            {
                using (BinaryReader reader = new BinaryReader(File.Open("../../../Class.txt", FileMode.Open)))
                {
                    try
                    {
                        while (true)
                        {
                            Class lop = new Class(reader.ReadString(), reader.ReadString(), reader.ReadString(), reader.ReadString(), new List<Student>());
                            listclass.Add(lop);
                            ManagerIndustry.CheckIndustry(lop.IDIndustry1).Listclass.Add(lop);
                            ManagerSchoolYear.CheckSchoolYear(lop.IDSY1).Listclass.Add(lop);
                        }
                    }
                    catch (Exception e)
                    {
                    }
                }
            }
            catch (Exception e)
            {

            }
        }
    }
}
