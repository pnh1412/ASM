﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ASM.Manager;
using ASM.Model;

namespace ASM.Manager
{
    class ManagerStudent
    {
        public static List<Student> liststudent = new List<Student>();
        public static Student checkStudent(string ID) {
            foreach (Student sv in liststudent) {
                if (sv.ID1.Equals(ID)) {
                    return sv;
                }
            }
            return null;
        }
        public static void addStudent(string IOC) {
            string ID;
            string IDIndustry;
            string Name;
            string DOF;
            string Gender;
            string Address;
            string PhoneNumber;
            Student sv;
            do
            {
                Console.Write("ID of Student: ");
                ID = Console.ReadLine();
                sv = ManagerStudent.checkStudent(ID);
                if (sv != null)
                {
                    Console.WriteLine("The ID exist");
                    Console.WriteLine("Pleas put the ID again!");
                }
            } while (sv != null);
            Console.WriteLine("Industry code: ");
            IDIndustry = Console.ReadLine();
            Console.WriteLine("Name of Student: ");
            Name = Console.ReadLine();
            Console.WriteLine("Date of Birth: ");
            DOF = Console.ReadLine();
            Console.WriteLine("Gender: ");
            Gender = Console.ReadLine();
            Console.WriteLine("Address: ");
            Address = Console.ReadLine();
            Console.WriteLine("Phone Number: ");
            PhoneNumber = Console.ReadLine();
            sv = new Student(ID,IDIndustry,IOC,Name,DOF,Gender,Address,PhoneNumber);
            liststudent.Add(sv);
            WriteFile();
            ManagerClass.CheckClass(ID).Liststudent.Add(sv);
        }
        public static void DeleteStudent(Class lop) {
            Console.Write("Enter your ID: ");
            string ID = Console.ReadLine();
            Student sv;
            sv = ManagerStudent.checkStudent(ID);
            if (sv == null)
            {
                Console.WriteLine("Didnt found student ");
            }
            else {
                liststudent.Remove(sv);
                lop.Liststudent.Remove(sv);
                WriteFile();
            }
        }
        public static void display(Class lop) {
            int check = 0;
            Console.WriteLine("Clss {0}", lop.NameClass1);
            Console.WriteLine("ID\t|Industrycode\t|Name\t|Date of Birth\t|Gender\t|Address\t|Phone Number\t|");
            foreach (Student sv in lop.Liststudent) {
                check++;
                Console.WriteLine("{0}\t|{1}\t|{2}\t|{3}\t|{4}\t|{5}\t|{6}\t", sv.ID1, sv.IOC1, sv.Name1,sv.DOF1,sv.Gender1,sv.Address1,sv.PhoneNumber1);
            }
            if(check == 0){
                Console.WriteLine("There is no Student");
            }
        }
        public static void WriteFile() {
            string fileName = "../../../Student.txt";
            using (BinaryWriter writter = new BinaryWriter(File.Open(fileName, FileMode.Create))) {
                foreach (Student sv in liststudent) {
                    writter.Write(sv.ID1);
                    writter.Write(sv.IOC1);
                    writter.Write(sv.IDIndustry1);
                    writter.Write(sv.Name1);
                    writter.Write(sv.DOF1);
                    writter.Write(sv.Gender1);
                    writter.Write(sv.Address1);
                    writter.Write(sv.PhoneNumber1);
                }
            }
        }
        public static void readFile() {
            try
            {
                using (BinaryReader reader = new BinaryReader(File.Open("../../../Student.txt", FileMode.Open)))
                {
                    try
                    {
                        while (true)
                        {
                            Student sv = new Student(reader.ReadString(), reader.ReadString(), reader.ReadString(), reader.ReadString(), reader.ReadString(), reader.ReadString(), reader.ReadString(), reader.ReadString());
                            liststudent.Add(sv);
                            ManagerClass.CheckClass(sv.IOC1).Liststudent.Add(sv);
                        }
                    }
                    catch (Exception e)
                    {
                    }
                }
            }
            catch (Exception e) {
                
            }
        }
    }
}
